# Cat and Dog > 2023-11-03 4:13pm
https://universe.roboflow.com/rrs-oh54g/cat-and-dog-qk2jc

Provided by a Roboflow user
License: CC BY 4.0

